package com.geekster.University.Event.Management.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityEventManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
